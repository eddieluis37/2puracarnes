<div>
	<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Pos_Create')): ?>
	<div class="row layout-top-spacing">

		<div class="col-sm-12 col-md-8">
			<!-- DETALLES -->
			<?php echo $__env->make('livewire.pos.partials.detail', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		</div>

		<div class="col-sm-12 col-md-4">
			<!-- TOTAL -->
			<?php echo $__env->make('livewire.pos.partials.total', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

			<!-- SELECCIONE MEDIO DE PAGO -->
			<?php echo $__env->make('livewire.pos.partials.type', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

				<?php if($status == "EFECTIVO"): ?>
					<!-- DENOMINATIONS -->
					<?php echo $__env->make('livewire.pos.partials.coins', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>								
				<?php else: ?>
					<?php echo $__env->make('livewire.pos.partials.toclose', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
				<?php endif; ?>	
						
		</div>

	</div>
	<?php endif; ?>

</div>

<script src="<?php echo e(asset('js/keypress.js')); ?>"></script>
<script src="<?php echo e(asset('js/onscan.js')); ?>"></script>
<script>
	try {

		onScan.attachTo(document, {
			suffixKeyCodes: [13],
			onScan: function(barcode) {
				console.log(barcode)
				window.livewire.emit('scan-code', barcode)
			},
			onScanError: function(e) {
				//console.log(e)
			}
		})

		console.log('Scanner ready!')


	} catch (e) {
		console.log('Error de lectura: ', e)
	}
</script>


<?php echo $__env->make('livewire.pos.scripts.shortcuts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('livewire.pos.scripts.events', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('livewire.pos.scripts.general', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/upuracaydh/puracarnes/resources/views/livewire/pos/component.blade.php ENDPATH**/ ?>