<div class="row mt-3">	
	<div class="col-sm-12">
		<div>
			<div class="connect-sorting">
				
				<h5 class="text-center mb-3">SELECCIONE</h5>

				<div class="connect-sorting-content">
					<div class="card simple-title-task ui-sortable-handle">
						<div class="card-body">

							<div class="btn-toolbar justify-content-between">
								<div class="col-sm-8">
								
									<div class="task-header">

										<div class="form-group">

											<label>Cliente</label>
											<select wire:model="thirdid" class="form-control">
												<option value="Elegir" selected>Elegir</option>					                                
				                                <?php $__currentLoopData = $thirds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				                                <option value="<?php echo e($t->id); ?>"><?php echo e($t->name); ?></option>
				                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				                            </select>
											<?php $__errorArgs = ['thirdid'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger er"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
										</div>

									</div>							

								</div>
								
								<div class="col-sm-4">
								
									<div class="task-header">

										<div class="form-group">

											<label>Pago</label>
											<select wire:model='status' class="form-control">
												<option value="Elegir" selected>Elegir</option>	
												<option value="CONTRAENTREGA">ContraEntrega</option>
												<option value="CREDITO">Credito</option>
												<option value="EFECTIVO">Efectivo</option>
												<option value="WONPI">Wompi</option>						
												
											</select>
											<?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger er"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
										</div>

									</div>							

								</div>

								
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>

	</div>
</div><?php /**PATH /home/upuracaydh/puracarnes/resources/views/livewire/pos/partials/type.blade.php ENDPATH**/ ?>