require('./bootstrap');
require('./script');
require('alpinejs');
