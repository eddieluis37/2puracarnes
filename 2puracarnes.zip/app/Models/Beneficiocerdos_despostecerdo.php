<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Beneficiocerdos_despostecerdo extends Model
{
    use HasFactory;
}
